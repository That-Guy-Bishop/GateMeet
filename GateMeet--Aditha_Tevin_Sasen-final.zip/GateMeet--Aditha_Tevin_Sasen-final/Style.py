Python 3.10.2 (tags/v3.10.2:a58ebcc, Jan 17 2022, 14:12:15) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
body {
    background-color: #f2f2f2;
    font-family: 'Arial', sans-serif;
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

.container {
    background-color: #4e54c8;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

h1 {
    color: #ffffff;
}

label {
    color: #ffffff;
    margin-right: 10px;
}

input {
    padding: 8px;
    margin-right: 10px;
    border: none;
    border-radius: 4px;
}

button {
    background-color: #ff79c6;
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: #bd93f9;
}

a {
    color: #ffffff;
    text-decoration: underline;
}
